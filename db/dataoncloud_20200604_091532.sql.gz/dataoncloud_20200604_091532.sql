-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: dataoncloud
-- ------------------------------------------------------
-- Server version	5.7.29-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `oc_document`
--

DROP TABLE IF EXISTS `oc_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_document` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `docname` varchar(255) DEFAULT NULL COMMENT '文档名称',
  `realname` varchar(255) DEFAULT NULL COMMENT '文档上传真实名称',
  `perfix` varchar(255) DEFAULT NULL COMMENT '文档格式',
  `docpath` varchar(255) DEFAULT NULL COMMENT '文档路径',
  `docsize` bigint(255) DEFAULT NULL COMMENT '文档大小',
  `doclabel` varchar(255) DEFAULT NULL COMMENT '文档标签',
  `docdescribe` varchar(255) DEFAULT NULL COMMENT '文档描述',
  `downloadfrequency` bigint(255) DEFAULT NULL COMMENT '文档被下载次数',
  `uploadtime` date DEFAULT NULL COMMENT '文档上传时间',
  `uid` bigint(11) DEFAULT NULL COMMENT '文档所有者id',
  `isshared` varchar(255) DEFAULT NULL COMMENT '是否共享',
  `isdelete` varchar(255) DEFAULT NULL COMMENT '是否被删除',
  `isaudit` varchar(255) DEFAULT NULL COMMENT '是否通过审核',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_document`
--

LOCK TABLES `oc_document` WRITE;
/*!40000 ALTER TABLE `oc_document` DISABLE KEYS */;
INSERT INTO `oc_document` VALUES (1,'测试文档','106015de-1dcd-4d17-a07e-5bcdc0ac70b8.doc','doc','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',60416,'文档','这是一个测试文档',10,'2020-04-25',1,'1','1','1'),(2,'测试文档2','77b9b65c-44a2-4a76-a3c3-3e9f8b694e7a.doc','doc','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',60416,'测试','12456',2,'2020-04-26',1,'1','1','0'),(3,'测试文档3','1f6c4c5e-16a7-41d5-9774-38c55850b4d8.html','html','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',1253,'测试','测试',5,'2020-04-26',1,'0','1','0'),(4,'测试文档478','367e1de7-3ce8-4715-8041-72fd6a0ab28a.html','html','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',2861,'测试','嘻嘻',6,'2020-04-26',1,'0','1','0'),(5,'测试文档55','e400842a-ef7b-4bf5-bca7-54474053ab59.html','html','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',5337,'测试','12365',5,'2020-04-26',1,'1','1','1'),(6,'测试文档77','15e7fa0d-61ed-45a7-91c7-fdb238a18d9c.html','html','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',3170,'测试','测试文件一个',2,'2020-04-26',4,'1','0','1'),(7,'测试文档9797','e1dad5b9-e3ff-4cb5-aadc-b5c7a8d55931.docx','docx','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',13927,'测试','78954122',1,'2020-04-26',3,'1','0','1'),(8,'测试文档嘻嘻','fff0355a-0d7b-47b5-8d87-bea48e475a56.docx','docx','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',13927,'1234564654','cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc',1,'2020-04-26',1,'1','1','1'),(9,'测试aaaa','e121e06b-2d8e-44b2-9b8d-45980c36c04e.jpg','jpg','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',72375,'','1231654654',2,'2020-04-26',1,'1','1','1'),(10,'测试','b00df296-ce86-4e65-b860-03f376c255f5.jpg','jpg','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',74958,'','',3,'2020-04-26',1,'0','0','0'),(11,'测试文档吸一下','83573cb4-cf04-47e7-ad2f-37197a1e7f93.jpg','jpg','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',66825,'测试','44645611',0,'2020-04-26',1,'1','1','0'),(12,'测是的东西','4e1afbb6-f353-4d0a-aa0a-33002bf9b701.jpg','jpg','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',70215,'测试','1231546464',0,'2020-04-26',2,'1','0','0'),(13,'测试文档1111','89c1a33c-067b-4081-a246-59e923d33240.jpg','jpg','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',70215,'测试','这又是一次测试',0,'2020-04-26',1,'1','0','0'),(14,'测试问顶顶顶顶顶','c31855ca-95a5-4ab4-a119-cd7756d58850.jpg','jpg','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',87269,'测试','123456',0,'2020-04-26',5,'1','0','0'),(15,'测试文档','d7a27cb0-9415-4a94-92a1-9b0a78d66ecf.jpg','jpg','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',74958,'aaaa','123456',0,'2020-04-26',1,'1','0','0'),(16,'测试787yhyh','7e3d2166-5e09-4907-9439-9234ca067f77.jpg','jpg','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',70215,'123456','1234',0,'2020-04-26',1,'0','0','0'),(17,'测试文档7785','02a32d80-3aff-467c-b955-2e628f7811fe.xlsx','xlsx','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',10159,'测试','测试表单和文档是否会被清空',0,'2020-04-26',1,'1','0','0'),(18,'测试文档223','7cbac6d5-a930-4de4-b03e-df66f45d5026.xls','xls','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',32768,'文档类','这是一个测试文档',1,'2020-05-09',1,'1','0','1'),(19,'测试文档443','4f998ce1-ada2-403b-9470-44593b9d6ba5.xls','xls','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',32768,'文档','这是一个测试文档443',0,'2020-05-09',1,'0','0','1'),(20,'测试文档222222','ce958cd5-6f80-49f9-9eec-1143f7834fea.docx','docx','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',17317,'文档','这是一个测试文档222222222222222',0,'2020-05-09',1,'1','0','1'),(21,'测试文档456','18fbbde9-ee03-49fd-9a95-0760487d8d1d.jpg','jpg','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',296792,'文档','这是一个测试文档4456',0,'2020-05-09',1,'0','0','0'),(22,'文档文档','4dbe3867-f43d-47c0-b551-857dd3114cda.docx','docx','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',17317,'测试','这是一个文档文档',0,'2020-05-09',1,'0','0','0'),(23,'文档哈哈','90709dcb-b3ad-4dc8-8d4a-05ad9162274b.docx','docx','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',17317,'测试','此文件测试用的',0,'2020-05-09',1,'0','0','0'),(24,'我的文档','a6f7b99a-fde4-430a-93c7-3df06114f781.docx','docx','E:\\MyProjects-private\\IdeaProjects\\oncloud-boot\\FileLibrary\\',17317,'测试','123456',0,'2020-05-09',1,'0','0','0');
/*!40000 ALTER TABLE `oc_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_menu`
--

DROP TABLE IF EXISTS `oc_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `perms` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `order_num` int(11) DEFAULT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_menu`
--

LOCK TABLES `oc_menu` WRITE;
/*!40000 ALTER TABLE `oc_menu` DISABLE KEYS */;
INSERT INTO `oc_menu` VALUES (1,0,'首页',NULL,NULL,'0','system',0),(2,1,'管理员列表','authc_list',NULL,'1','admin',1),(3,1,'角色管理','role_list',NULL,'1','role',2),(4,1,'菜单管理','menu_list',NULL,'1','menu',3),(5,0,'文件管理',NULL,NULL,'0','system',0),(6,5,'文件列表','doc_list',NULL,'1','',1),(7,5,'文件上传','doc_upload',NULL,'1',NULL,2),(8,1,'审核','audit','oc:doc:audit','1',NULL,4),(9,5,'文件大厅','doc_hall','','1',NULL,3);
/*!40000 ALTER TABLE `oc_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_role`
--

DROP TABLE IF EXISTS `oc_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '唯一标识',
  `role_name` varchar(255) DEFAULT NULL COMMENT '角色名称',
  `remark` varchar(0) DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL COMMENT '创建此角色的用户Id',
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_role`
--

LOCK TABLES `oc_role` WRITE;
/*!40000 ALTER TABLE `oc_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_role_menu`
--

DROP TABLE IF EXISTS `oc_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_role_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_role_menu`
--

LOCK TABLES `oc_role_menu` WRITE;
/*!40000 ALTER TABLE `oc_role_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_user`
--

DROP TABLE IF EXISTS `oc_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_user` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) DEFAULT NULL COMMENT '用户密码',
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL COMMENT '用户角色',
  `create_time` datetime DEFAULT NULL,
  `state` tinyint(4) DEFAULT NULL COMMENT '状态',
  `isdelete` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_user`
--

LOCK TABLES `oc_user` WRITE;
/*!40000 ALTER TABLE `oc_user` DISABLE KEYS */;
INSERT INTO `oc_user` VALUES (1,'admin','admin',NULL,NULL,'超级管理员',NULL,1,'0'),(2,'liming','123456',NULL,NULL,'管理员',NULL,1,'0'),(3,'zhangsan','123456',NULL,NULL,'管理员',NULL,1,'0'),(4,'wangwu','321654',NULL,NULL,'管理员',NULL,1,'0'),(5,'lisi','456789',NULL,NULL,'用户',NULL,1,'0'),(6,'yuhongyang','879704116',NULL,NULL,'用户',NULL,1,'1'),(7,'liuming','liuliuqiu',NULL,NULL,'用户',NULL,0,'1'),(8,'hongyang','123456789',NULL,NULL,'用户',NULL,1,'1'),(9,'yuyuyuyu','123456',NULL,NULL,'用户',NULL,1,'0'),(10,'hahaha','456789',NULL,NULL,'用户',NULL,1,'0');
/*!40000 ALTER TABLE `oc_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_user_role`
--

DROP TABLE IF EXISTS `oc_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_user_role`
--

LOCK TABLES `oc_user_role` WRITE;
/*!40000 ALTER TABLE `oc_user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_user_token`
--

DROP TABLE IF EXISTS `oc_user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_user_token` (
  `user_id` int(11) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `expirer_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_user_token`
--

LOCK TABLES `oc_user_token` WRITE;
/*!40000 ALTER TABLE `oc_user_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_user_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-04  9:15:32
